package com.example.videocompanion

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {
    private lateinit var root: LinearLayout
    private lateinit var player: VideoView
    private lateinit var status: TextView
    private lateinit var playPause: Button
    private var chosenUri: Uri? = null
    private var prepared = false
    private var playing = false
    private var showApps = false

    private val videoPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {}
            chosenUri = uri
            prepared = false
            status.text = "Loading video…"
            player.setVideoURI(uri)
        }
    }

    private data class CallingApp(val label: String, val pkg: String)

    private val callingApps = listOf(
        CallingApp("Telegram", "org.telegram.messenger"),
        CallingApp("WhatsApp", "com.whatsapp"),
        CallingApp("Messenger", "com.facebook.orca"),
        CallingApp("Facebook", "com.facebook.katana"),
        CallingApp("Signal", "org.thoughtcrime.securesms"),
        CallingApp("Zoom", "us.zoom.videomeetings"),
        CallingApp("Google Meet", "com.google.android.apps.meetings"),
        CallingApp("Microsoft Teams", "com.microsoft.teams")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildHome()
        player.setOnPreparedListener { mp ->
            prepared = true
            mp.isLooping = true
            player.start()
            playing = true
            playPause.text = "Pause"
            status.text = "Playing selected video • Loop on"
        }
        player.setOnCompletionListener {
            player.seekTo(0)
            player.start()
        }
        player.setOnErrorListener { _, _, _ ->
            status.text = "Can't play this file. Please choose another video."
            prepared = false
            true
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView {
        return TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
        }
    }

    private fun button(value: String, onClick: () -> Unit): Button {
        return Button(this).apply {
            text = value
            isAllCaps = false
            setOnClickListener { onClick() }
        }
    }

    private fun buildBase(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF111111.toInt())
        }
        setContentView(root)
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(18), dp(16), dp(18))
            setBackgroundColor(0xFF202020.toInt())
        }
        bar.addView(text(title, 24f, 0xFFFFFFFF.toInt(), true), LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(text("⋮", 30f, 0xFFFFFFFF.toInt()))
        root.addView(bar)
    }

    private fun buildHome() {
        showApps = false
        buildBase("Video Companion")
        val scroll = ScrollView(this)
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(24))
        }
        body.addView(text("YOUR VIDEO LIBRARY", 13f, 0xFFAAAAAA.toInt(), true))
        body.addView(TextView(this).apply {
            text = "Choose a clip to play while you share your screen during a call."
            textSize = 14f
            setTextColor(0xFFCCCCCC.toInt())
            setPadding(0, dp(8), 0, dp(16))
        })
        player = VideoView(this).apply {
            setBackgroundColor(0xFF050505.toInt())
        }
        body.addView(player, LinearLayout.LayoutParams(-1, dp(250)))
        status = text("No video selected", 14f, 0xFFCCCCCC.toInt())
        status.setPadding(0, dp(12), 0, dp(8))
        body.addView(status)
        body.addView(button("＋  Add video from gallery") {
            videoPicker.launch(arrayOf("video/*"))
        }, LinearLayout.LayoutParams(-1, -2))
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        playPause = button("Play") {
            if (!prepared) {
                status.text = if (chosenUri == null) "Choose a video first." else "Video is still loading."
            } else if (playing) {
                player.pause(); playing = false; playPause.text = "Play"
            } else {
                player.start(); playing = true; playPause.text = "Pause"
            }
        }
        controls.addView(playPause, LinearLayout.LayoutParams(0, -2, 1f))
        controls.addView(button("Start over") {
            if (prepared) { player.seekTo(0); player.start(); playing = true; playPause.text = "Pause" }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        body.addView(controls)
        body.addView(button("Choose calling app") { buildApps() }, LinearLayout.LayoutParams(-1, -2))
        val note = text(
            "During a call, use that app's own screen-sharing control if available. Participants will see your shared playback screen, not a live camera replacement.",
            12f, 0xFFBDBDBD.toInt()
        )
        note.setPadding(0, dp(14), 0, 0)
        body.addView(note)
        scroll.addView(body)
        root.addView(scroll)
    }

    private fun buildApps() {
        showApps = true
        buildBase("Device Apps")
        val search = EditText(this).apply {
            hint = "Search calling apps"
            setHintTextColor(0xFF999999.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            setSingleLine(true)
            setPadding(dp(16), dp(10), dp(16), dp(10))
        }
        root.addView(search)
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), 0, dp(16), dp(8))
        }
        val rows = mutableListOf<Pair<CallingApp, View>>()
        callingApps.forEach { app ->
            val installed = try {
                packageManager.getApplicationInfo(app.pkg, 0)
                true
            } catch (_: Exception) { false }
            if (installed) {
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(10), dp(14), dp(10), dp(14))
                }
                val icon = try { packageManager.getApplicationIcon(app.pkg) } catch (_: Exception) { null }
                if (icon != null) {
                    row.addView(ImageView(this).apply { setImageDrawable(icon) },
                        LinearLayout.LayoutParams(dp(42), dp(42)))
                }
                val label = text(app.label, 17f, 0xFFFFFFFF.toInt())
                label.setPadding(dp(14), 0, 0, 0)
                row.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
                row.addView(button("Open") {
                    try { startActivity(packageManager.getLaunchIntentForPackage(app.pkg)) }
                    catch (_: Exception) { Toast.makeText(this, "Unable to open app", Toast.LENGTH_SHORT).show() }
                })
                list.addView(row)
                val divider = View(this).apply { setBackgroundColor(0xFF303030.toInt()) }
                list.addView(divider, LinearLayout.LayoutParams(-1, dp(1)))
                rows.add(app to row)
            }
        }
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                rows.forEach { (app, view) ->
                    view.visibility = if (app.label.contains(s.toString(), true)) View.VISIBLE else View.GONE
                }
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        val scroll = ScrollView(this)
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(button("Back to video library") { buildHome() })
    }

    override fun onBackPressed() {
        if (showApps) buildHome() else super.onBackPressed()
    }

    override fun onPause() {
        super.onPause()
        if (::player.isInitialized && player.isPlaying) {
            player.pause()
            playing = false
            if (::playPause.isInitialized) playPause.text = "Play"
        }
    }
}
