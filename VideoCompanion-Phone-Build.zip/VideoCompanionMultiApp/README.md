# Video Companion — Android phones and tablets

This Android Studio project follows the supplied Multi Run visual references: dark theme, app-bar layout, rounded/clean app list styling, and a device-app selection screen.

## Included
- Pick a video from the device using Android's document picker.
- Preview, play, pause, restart, and loop the selected clip.
- Search a list of supported calling apps that are installed on the device.
- Open Telegram, WhatsApp, Messenger, Facebook, Signal, Zoom, Google Meet, or Microsoft Teams when installed.
- Responsive Android layout that adapts to phone and tablet screen sizes.

## Important limitation
This is a transparent video playback companion. It does not replace a calling app's live camera feed with prerecorded footage. On a call, use the calling app's screen-sharing feature where supported; other participants will see the shared screen/video. Tell participants when content is prerecorded.

## Build and install
1. Open this folder in Android Studio.
2. Allow Gradle sync (JDK 17 recommended).
3. Connect an Android phone/tablet or start an emulator.
4. Press Run to install.

Minimum Android version: Android 8.0 (API 26).
